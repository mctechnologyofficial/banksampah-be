const banksampah = require('./banksampah')
const authorization = require('./authorization')

module.exports = {
  banksampah: banksampah,
  authorization: authorization
}