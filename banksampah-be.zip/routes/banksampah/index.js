const express = require('express');
const router = express.Router();
const auth = require('../../middlewares/authorization')
const controller = require('../../config/controllers')

router.get('/v1/getAllUsers', auth.doAuth, controller.usercontroller.getAllUsers)

module.exports = router