const controller = {}
const usercontroller = require('./users')

controller.usercontroller = usercontroller

module.exports = controller