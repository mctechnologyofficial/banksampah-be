const controller = {}
const service = require('./service')
const status = require('../../../helpers/status_helpers')

controller.getAllUsers = async(req, res) => {
    try {
        let result = await service.getAllUsers()

        return res.status(status.statusCode.success).json(status.successMessage(result))
    } catch (error) {
        console.log(error)
        return res.status(status.statusCode.bad).json(status.errorMessage(error))
    }
}

module.exports = controller