const service = {}
const model = require('../../models')

service.getAllUsers = async() => {
    let result = await model.td_users.findAll()

    return result
}

module.exports = service